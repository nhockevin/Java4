package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class Testketnoi {

	public static void main(String[] args) {
		// create();
		// delete();
		findAll();
		findByRole(true);
		findPage(0, 3);
	}

	private static void findAll() {
		EntityManagerFactory emf = null;
		EntityManager em = null;

		try {
			emf = Persistence.createEntityManagerFactory("PolyOE");
			em = emf.createEntityManager();
			
			String jpql = "SELECT u FROM User u";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">> Email: " + user.getEmail());
				System.out.println(">> Quyen: " + user.getAdmin());
				System.out.println(">> ID: " + user.getId());
				System.out.println(">> Password: " + user.getPassword());
				System.out.println(">> Ten day du: " + user.getFullname());
				System.out.println("----------------------------");
			}

			System.out.println("Truy vấn thành công!");

		} catch (Exception e) {
			System.out.println("Truy vấn thất bại!");
			e.printStackTrace();
		} finally {
			if (em != null && em.isOpen()) {
				em.close();
			}
			if (emf != null && emf.isOpen()) {
				emf.close();
			}
		}
	}

	private static void create() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			User entity = new User();

			entity.setId("nv1213");
			entity.setEmail("TULA20@FE.EDU.VN");
			entity.setPassword("abc");
			entity.setFullname("HELLO SD306");
			entity.setAdmin(true);
			
			em.persist(entity);

			em.getTransaction().commit();

			System.out.println("Thêm thành công!");
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Thêm thất bại!");
		}
		em.close();
		emf.close();
	}

	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();

			User entity = em.find(User.class, "nv1213");
			em.remove(entity);

			em.getTransaction().commit();
			System.out.println("Delete thành công!");
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Delete thất bại!");
		}
		em.close();
		emf.close();
	}

	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();

			User entity = em.find(User.class, "nv01");
			entity.setPassword("ILOVEYOU");
			entity.setAdmin(false);
			entity.setFullname("ĐÀM VĨNH HƯNG");
			em.merge(entity);

			em.getTransaction().commit();
			System.out.println("Update thành công!");
		} catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Update thất bại!");
		}
		em.close();
		emf.close();
	}

	private static void findByRole(boolean role) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "SELECT o FROM User o WHERE o.Admin=:role";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("role", role);

			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy vấn thành công!");
		} catch (Exception e) {
			System.out.println("Truy vấn lỗi!");
		}
		em.close();
		emf.close();
	}

	private static void findByKeyword(String email, String fullname) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "SELECT o FROM User o WHERE o.Email LIKE ?0 OR o.Fullname LIKE ?1";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter(0, email);
			query.setParameter(1, fullname);

			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy vấn thành công!");
		} catch (Exception e) {
			System.out.println("Truy vấn thất bại!");
		}
		em.close();
		emf.close();
	}

	private static void findByFullname(String fullname) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "SELECT o FROM User o WHERE o.Fullname LIKE :fullname";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("fullname", "%" + fullname + "%");

			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Fullname: " + user.getFullname());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy vấn thành công!");
		} catch (Exception e) {
			System.out.println("Truy vấn thất bại! Lỗi: " + e.getMessage());
		} finally {
			em.close();
			emf.close();
		}
	}

	private static void findPage(int page, int size) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "SELECT o FROM User o";
			
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setFirstResult(page * size);
			query.setMaxResults(size);

			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}

			System.out.println("Truy vấn thành công!");
		} catch (Exception e) {
			System.out.println("Truy vấn thất bại!");
		}
		em.close();
		emf.close();
	}
}