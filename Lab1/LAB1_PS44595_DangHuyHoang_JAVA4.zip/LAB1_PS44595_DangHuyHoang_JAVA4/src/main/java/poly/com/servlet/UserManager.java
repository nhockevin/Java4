package poly.com.servlet;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class UserManager {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = factory.createEntityManager();
	
	public void findAll() {
		String jpql = "SELECT o FROM User o";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		List<User> list = query.getResultList();
		list.forEach(user -> {
		String fullname = user.getFullname();
		boolean admin = user.getAdmin();
		System.out.println(fullname +": " + admin);
		});
	}
	public void findById() {}
	public void create() {}
	public void update() {}
	public void deleteById() {}
}